/*
 * This file is generated. Do not change it manually.
 */

package de.unistuttgart.hamster.hamster;

import de.unistuttgart.iste.sqa.mpw.framework.mpw.Prop;

public class Clover extends Prop {

	public Clover() {

	}

}
