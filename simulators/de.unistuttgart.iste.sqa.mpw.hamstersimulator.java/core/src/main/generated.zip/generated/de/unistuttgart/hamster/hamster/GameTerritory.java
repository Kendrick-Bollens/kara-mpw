/*
 * This file is generated. Do not change it manually.
 */

package de.unistuttgart.hamster.hamster;

import de.unistuttgart.hamster.hamster.ReadOnlyTerritory;

public interface GameTerritory extends ReadOnlyTerritory {

	GameHamster getGameDefaultHamster();

}
