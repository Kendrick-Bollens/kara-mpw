package de.unistuttgart.hamster.commands.hamster;

import de.unistuttgart.hamster.hamster.*;

import de.unistuttgart.iste.sqa.mpw.framework.mpw.*;
import de.unistuttgart.iste.sqa.mpw.framework.datatypes.*;
import de.unistuttgart.iste.sqa.mpw.framework.commands.*;

public class TurnLeftCommandParameters {
	public ConcreteHamster self;
	public CommandStack commandStack;
	public GameLog gameLog;

}
