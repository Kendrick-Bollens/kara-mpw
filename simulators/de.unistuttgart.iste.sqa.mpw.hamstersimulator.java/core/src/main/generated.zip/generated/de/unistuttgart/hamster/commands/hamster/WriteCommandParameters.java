package de.unistuttgart.hamster.commands.hamster;

import de.unistuttgart.hamster.hamster.*;

import de.unistuttgart.iste.sqa.mpw.framework.mpw.*;
import de.unistuttgart.iste.sqa.mpw.framework.datatypes.*;
import de.unistuttgart.iste.sqa.mpw.framework.commands.*;

public class WriteCommandParameters {
	public ConcreteHamster self;
	public CommandStack commandStack;
	public GameLog gameLog;

	public String message;

}
